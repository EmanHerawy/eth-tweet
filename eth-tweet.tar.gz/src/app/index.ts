export * from './auth/auth.component';
export * from './auth/add-auth/add-auth.component';
export * from './home/home.component';
export * from './login/login.component';
export * from './/members/member.component';
// export * from './user/user-add/user-add.component';
// export * from './user/add-dna/add-dna.component';
// export * from './user/user-edit/user-edit.component';
// export * from './user/user-search/user-search.component';

