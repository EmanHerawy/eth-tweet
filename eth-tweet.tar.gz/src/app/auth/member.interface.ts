export interface Member {
  id: number;
  name: string;
  address: string;
  isActive: boolean;

}
